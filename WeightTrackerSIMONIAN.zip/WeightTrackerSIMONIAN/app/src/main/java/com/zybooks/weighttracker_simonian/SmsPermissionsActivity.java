package com.zybooks.weighttracker_simonian;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsPermissionsActivity extends AppCompatActivity {

    private long userId;

    // Asks the user for SMS permission, then continues to the main screen either way
    private final ActivityResultLauncher<String> smsPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
        if (granted) {
            Toast.makeText(this, "Text notifications enabled", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Text notifications disabled", Toast.LENGTH_SHORT).show();
        }
        openMainScreen();
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permissions);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, -1);

        Button enableButton = findViewById(R.id.buttonEnableSms);
        enableButton.setOnClickListener(v -> smsPermissionLauncher.launch(Manifest.permission.SEND_SMS));

        Button noThanksButton = findViewById(R.id.buttonNoThanks);
        noThanksButton.setOnClickListener(v -> openMainScreen());
    }

    private void openMainScreen() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(LoginActivity.EXTRA_USER_ID, userId);
        startActivity(intent);
        finish();
    }
}