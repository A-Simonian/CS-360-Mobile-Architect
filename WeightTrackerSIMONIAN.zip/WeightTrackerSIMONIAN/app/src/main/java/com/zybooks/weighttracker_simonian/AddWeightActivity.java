package com.zybooks.weighttracker_simonian;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;
import java.util.Locale;
// Screen for adding a new weight entry or editing an existing one
public class AddWeightActivity extends AppCompatActivity {

    private long userId;
    private WeightDatabaseHelper dbHelper;
    private EditText dateInput;
    private EditText weightInput;
    private RadioGroup unitGroup;
    // Keys for passing an existing entry's values in when editing
    public static final String EXTRA_ENTRY_ID = "com.zybooks.weighttracker_simonian.ENTRY_ID";
    public static final String EXTRA_DATE = "com.zybooks.weighttracker_simonian.DATE";
    public static final String EXTRA_WEIGHT = "com.zybooks.weighttracker_simonian.WEIGHT";
    public static final String EXTRA_UNIT = "com.zybooks.weighttracker_simonian.UNIT";


    private long entryId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_weight);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new WeightDatabaseHelper(this);
        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, -1);

        dateInput = findViewById(R.id.editDate);
        dateInput.setOnClickListener(v -> showDatePicker());
        weightInput = findViewById(R.id.editWeight);
        unitGroup = findViewById(R.id.radioGroupUnit);

        Button saveButton = findViewById(R.id.buttonSave);
        saveButton.setOnClickListener(v -> {
            String date = dateInput.getText().toString().trim();
            String weightText = weightInput.getText().toString().trim();

            if (date.isEmpty() || weightText.isEmpty()) {
                Toast.makeText(this, "Enter a date and weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight = Double.parseDouble(weightText);
            String unit = "lbs";
            if (unitGroup.getCheckedRadioButtonId() == R.id.radioKg) {
                unit = "kg";
            }
            if (entryId == -1) {
                dbHelper.addWeight(userId, date, weight, unit);
                Toast.makeText(this, "Weight added", Toast.LENGTH_SHORT).show();
            } else {
                dbHelper.updateWeight(entryId, date, weight, unit);
                Toast.makeText(this, "Entry updated", Toast.LENGTH_SHORT).show();
            }

            checkGoalReached(weight, unit);
            finish();
        });

        // Start with today's date filled in
        Calendar today = Calendar.getInstance();
        dateInput.setText(String.format(Locale.US, "%02d-%02d-%d", today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH), today.get(Calendar.YEAR)));

        // If an entry was passed in, fill in the fields with its values
        entryId = getIntent().getLongExtra(EXTRA_ENTRY_ID, -1);
        if (entryId != -1) {
            dateInput.setText(getIntent().getStringExtra(EXTRA_DATE));
            weightInput.setText(String.valueOf(getIntent().getDoubleExtra(EXTRA_WEIGHT, 0.0)));
            if ("kg".equals(getIntent().getStringExtra(EXTRA_UNIT))) {
                unitGroup.check(R.id.radioKg);
            }
        }
    }

    private void showDatePicker() {
        Calendar today = Calendar.getInstance();

        DatePickerDialog dialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            String date = String.format(Locale.US, "%02d-%02d-%d", month + 1, dayOfMonth, year);
            dateInput.setText(date);
        }, today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    // Checks whether the saved weight reached the user's goal and alerts them
    private void checkGoalReached(double weight, String unit) {
        double goal = dbHelper.getGoalWeight(userId);
        String goalUnit = dbHelper.getGoalUnit(userId);

        if (goal > 0 && unit.equals(goalUnit) && weight <= goal) {
            Toast.makeText(this, "Congratulations! You've reached your goal weight!", Toast.LENGTH_LONG).show();
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = getSystemService(SmsManager.class);
                smsManager.sendTextMessage("5554", null, "Congratulations! You've reached your goal weight!", null, null);
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
            }
        }
    }
}