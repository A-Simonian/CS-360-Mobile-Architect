package com.zybooks.weighttracker_simonian;

public class WeightEntry {

    private final long id;
    private final String date;
    private final double weight;
    private final String unit;

    public WeightEntry(long id, String date, double weight, String unit) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.unit = unit;
    }

    public long getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }

    public String getUnit() {
        return unit;
    }

}
