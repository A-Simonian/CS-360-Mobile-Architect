package com.zybooks.weighttracker_simonian;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// Connects the list of weight entries to the grid on the main screen
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final ArrayList<WeightEntry> entries;

    private final WeightDatabaseHelper dbHelper;

    private final long userId;


    // Creates the adapter with the list of entries to display
    public WeightAdapter(ArrayList<WeightEntry> entries, WeightDatabaseHelper dbHelper, long userId) {
        this.entries = entries;
        this.dbHelper = dbHelper;
        this.userId = userId;
    }

    // Tells the grid how many rows to draw
    @Override
    public int getItemCount() {
        return entries.size();
    }

    // Creates one row by loading the item_weight layout
    @Override
    public WeightViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new WeightViewHolder(row);
    }

    // Fills one row with the date and weight of the entry at this position
    @Override
    public void onBindViewHolder(WeightViewHolder holder, int position) {
        WeightEntry entry = entries.get(position);

        holder.dateText.setText(entry.getDate());
        holder.weightText.setText(entry.getWeight() + " " + entry.getUnit());

        // Deletes the entry when the delete button is clicked
        holder.deleteButton.setOnClickListener(v -> {
            int currentPosition = holder.getBindingAdapterPosition();
            WeightEntry clicked = entries.get(currentPosition);

            dbHelper.deleteWeight(clicked.getId());
            entries.remove(currentPosition);
            notifyItemRemoved(currentPosition);
        });

        // Open the Add Weight screen to edit entry when the edit button is clicked
        holder.editButton.setOnClickListener(v -> {
            WeightEntry clicked = entries.get(holder.getBindingAdapterPosition());

            Intent intent = new Intent(v.getContext(), AddWeightActivity.class);
            intent.putExtra(AddWeightActivity.EXTRA_ENTRY_ID, clicked.getId());
            intent.putExtra(AddWeightActivity.EXTRA_DATE, clicked.getDate());
            intent.putExtra(AddWeightActivity.EXTRA_WEIGHT, clicked.getWeight());
            intent.putExtra(AddWeightActivity.EXTRA_UNIT, clicked.getUnit());
            intent.putExtra(LoginActivity.EXTRA_USER_ID, userId);
            v.getContext().startActivity(intent);
        });

    }

    // Holds the views for one row of the grid
    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView dateText;
        TextView weightText;
        ImageButton deleteButton;
        ImageButton editButton;

        WeightViewHolder(View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.textDate);
            weightText = itemView.findViewById(R.id.textWeight);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
            editButton = itemView.findViewById(R.id.buttonEdit);
        }
    }
}