package com.zybooks.weighttracker_simonian;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SetGoalActivity extends AppCompatActivity {

    private long userId;
    private WeightDatabaseHelper dbHelper;
    private EditText goalInput;
    private RadioGroup unitGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_set_goal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new WeightDatabaseHelper(this);
        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, -1);

        goalInput = findViewById(R.id.editGoalWeight);
        unitGroup = findViewById(R.id.radioGroupUnit);

        Button saveButton = findViewById(R.id.buttonSave);
        saveButton.setOnClickListener(v -> {
            String goalText = goalInput.getText().toString().trim();
            if (goalText.isEmpty()) {
                Toast.makeText(this, "Enter a goal weight", Toast.LENGTH_SHORT).show();
                return;
            }
            double goal = Double.parseDouble(goalText);
            String unit = "lbs";
            if (unitGroup.getCheckedRadioButtonId() == R.id.radioKg) {
                unit = "kg";
            }
            dbHelper.setGoalWeight(userId, goal, unit);
            finish();
        });

    }
}

