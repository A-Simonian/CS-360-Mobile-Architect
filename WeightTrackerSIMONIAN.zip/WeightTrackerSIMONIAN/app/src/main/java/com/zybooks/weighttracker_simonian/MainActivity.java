package com.zybooks.weighttracker_simonian;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    private long userId;
    private WeightDatabaseHelper dbHelper;
    private TextView goalText;
    private RecyclerView weightList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new WeightDatabaseHelper(this);
        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, -1);

        goalText = findViewById(R.id.textGoal);
        weightList = findViewById(R.id.recyclerWeights);
        weightList.setLayoutManager(new LinearLayoutManager(this));
        Button setGoalButton = findViewById(R.id.buttonSetGoal);
        Button addWeightButton = findViewById(R.id.buttonAddWeight);

        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddWeightActivity.class);
            intent.putExtra(LoginActivity.EXTRA_USER_ID, userId);
            startActivity(intent);
        });

        setGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, SetGoalActivity.class);
            intent.putExtra(LoginActivity.EXTRA_USER_ID, userId);
            startActivity(intent);
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        double goal = dbHelper.getGoalWeight(userId);
        String unit = dbHelper.getGoalUnit(userId);

        if (goal == 0.0) {
            goalText.setText("Goal: not set");
        } else {
            goalText.setText("Goal: " + goal + " " + unit);
        }

        weightList.setAdapter(new WeightAdapter(dbHelper.getWeights(userId), dbHelper, userId));
    }
}