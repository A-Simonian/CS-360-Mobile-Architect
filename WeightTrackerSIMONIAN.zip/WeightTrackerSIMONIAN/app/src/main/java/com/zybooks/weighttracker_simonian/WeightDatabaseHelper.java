package com.zybooks.weighttracker_simonian;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

// Manages the SQLite database: creates the tables and provides methods to add, update, and delete data.
public class WeightDatabaseHelper extends SQLiteOpenHelper {

    // Database file info
    private static final String DATABASE_NAME = "weights.db";
    private static final int DATABASE_VERSION = 1;

    // Shared ID column(used in both tables)
    public static final String COLUMN_ID = "_id";

    // Users table: one row per account, including their goal
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    public static final String COLUMN_GOAL_UNIT = "goal_unit";

    // Weights table: one row per weight entry
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_UNIT = "unit";

    public WeightDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, " + COLUMN_PASSWORD + " TEXT NOT NULL, " + COLUMN_GOAL_WEIGHT + " REAL, " + COLUMN_GOAL_UNIT + " TEXT)");

        // Create the weights table
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USER_ID + " INTEGER NOT NULL, " + COLUMN_DATE + " TEXT, " + COLUMN_WEIGHT + " REAL, " + COLUMN_UNIT + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);

    }

    // Add a new user to the database. Returns the new user ID., or -1 if the username is already in use.
    public long addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        return db.insert(TABLE_USERS, null, values);

    }

    // Add a new weight entry to the database. Returns the new entry ID.
    public long addWeight(long userId, String date, double weight, String unit) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_UNIT, unit);

        return db.insert(TABLE_WEIGHTS, null, values);
    }

    // Checks a login. Returns the user ID if the login is successful, or -1 if it is not.
    public long checkCredentials(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT " + COLUMN_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?", new String[]{username, password});

        long userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getLong(0);
        }

        cursor.close();

        return userId;
    }

    // Gets the user's goal weight. Returns 0.0 if the user has no goal.
    public double getGoalWeight(long userId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_USERS + " WHERE " + COLUMN_ID + " = ?", new String[]{String.valueOf(userId)});

        double goalWeight = 0.0;

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
        }

        cursor.close();

        return goalWeight;
    }

    // Sets the user's goal weight. Returns true if the update is successful.
    public boolean setGoalWeight(long userId, double goalWeight, String goalUnit) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
        values.put(COLUMN_GOAL_UNIT, goalUnit);

        int rowsAffected = db.update(TABLE_USERS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(userId)});

        return rowsAffected > 0;
    }

    // Gets the user's goal unit. Returns "lbs" if the user has no goal.
    public String getGoalUnit(long userId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT " + COLUMN_GOAL_UNIT + " FROM " + TABLE_USERS + " WHERE " + COLUMN_ID + " = ?", new String[]{String.valueOf(userId)});

        String goalUnit = "lbs";

        if (cursor.moveToFirst()) {
            goalUnit = cursor.getString(0);
        }

        cursor.close();

        return goalUnit;
    }

    // Updates a weight entry's date and weight and unit. Returns true if the update is successful.
    public boolean updateWeight(long entryId, String date, double weight, String unit) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_UNIT, unit);
        int rowsAffected = db.update(TABLE_WEIGHTS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(entryId)});
        return rowsAffected > 0;

    }

    //Deletes a weight entry. Returns true if the delete is successful.
    public boolean deleteWeight(long entryId) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsAffected = db.delete(TABLE_WEIGHTS, COLUMN_ID + " = ?", new String[]{String.valueOf(entryId)});
        return rowsAffected > 0;

    }

    // Gets all weight entries for a user, most recent date first. Returns an empty list if there are none.
    public ArrayList<WeightEntry> getWeights(long userId) {
        ArrayList<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_ID + ", " + COLUMN_DATE + ", " + COLUMN_WEIGHT + ", " + COLUMN_UNIT + " FROM " + TABLE_WEIGHTS + " WHERE " + COLUMN_USER_ID + " = ? ORDER BY substr(" + COLUMN_DATE + ", 7, 4) || substr(" + COLUMN_DATE + ", 1, 2) || substr(" + COLUMN_DATE + ", 4, 2) DESC, " + COLUMN_ID + " DESC", new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String date = cursor.getString(1);
                double weight = cursor.getDouble(2);
                String unit = cursor.getString(3);
                entries.add(new WeightEntry(id, date, weight, unit));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return entries;
    }
}
